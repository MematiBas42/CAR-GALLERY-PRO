import SignInform from '@/components/auth/SignInform'
import React from 'react'

const SignInPage = () => {
  return (
    <div>
      <SignInform/>
    </div>
  )
}

export default SignInPage
