import OtpForm from '@/components/auth/otp-form'
import React from 'react'

const ChallengePage = () => {

  
  return (
    <OtpForm  />
  )
}

export default ChallengePage
