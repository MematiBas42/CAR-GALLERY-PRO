import React from 'react'

const CarLoading = () => {
  return (
    <div>
      
    </div>
  )
}

export default CarLoading
