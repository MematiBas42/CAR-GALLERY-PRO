import { MultiStepFormEnum } from "@/config/types";
import { z } from "zod";
export const MultiStepFormSchema = z.object({
  step: z.nativeEnum(MultiStepFormEnum),
  slug: z.string(),
});

export const validateIdSchema = z.object({
  id: z.number().int(),
});